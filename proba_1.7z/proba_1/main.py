# name ="Matvei"
# userName = "Matvei"
# user_name = "Matvei"
# name = "matvei"
# Name = "Matvei"
# print(name)
#
# myNamber=input(4)
# print(myNamber)

# myAge=input("16")
# print("16",myAge)

# isGood=True
# print(isGood)
# isAlive = False
# print(isAlive)

# myAge = 16
# print("возраст:", myAge)
# myCount = 88
# print("колличество:", myCount)

# myHeight = 1.67
# pi = 3.14
# weight = 50.
# print(myHeight)
# print(pi)
# print(weight)

