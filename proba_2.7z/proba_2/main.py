# while number < 5:
#     print(f"number = {number}")
#     number += 1
#     print("Работа программы завершена")
import math

number = 1

# while number < 5:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершена")
#     print("Работа программы завершена")

# i = 1
# j = 1
# while i < 10:
#     while j < 10:
#         print(i * j, end="\t")
#         j += 1
#     print("\n")
#     j = 1
#     i += 1

# number = 0
# while number < 5:
#     number += 1
#     if number == 3 :
#         break
#     print(f"number = {number}")

# a = -math.pi/2
# b = math.pi/2
# h = math.pi/10
# while a < b:
#     Y = math.pow(a, 2) * math.cos(a) * math.sin(a)
#     print(Y)
#     a += h

